#!/usr/bin/env python3
print('Welcome to the Brain Games!')


def main():
    None


if __name__ == '__main__':
    main()
