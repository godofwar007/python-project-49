### Hexlet tests and linter status:
[![Actions Status](https://github.com/godofwar007/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/godofwar007/python-project-49/actions)

<a href="https://codeclimate.com/github/godofwar007/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/15d3db42c6800a759520/maintainability" /></a>

[![asciicast](https://asciinema.org/a/7IbjslwESDUUrlVWxGLT8kteX.svg)](https://asciinema.org/a/7IbjslwESDUUrlVWxGLT8kteX)
