#!/usr/bin/env python3

from brain_games.prime_num import game_prime_n


def main():
    game_prime_n()


if __name__ == '__main__':
    main()
