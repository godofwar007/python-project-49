#!/usr/bin/env python3

from brain_games.calc_gcd import result_gcd


def main():
    result_gcd()


if __name__ == '__main__':
    main()
