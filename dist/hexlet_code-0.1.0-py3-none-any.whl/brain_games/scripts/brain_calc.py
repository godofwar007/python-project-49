#!/usr/bin/env python3

from brain_games.calc_game import correct_expression


def main():
    correct_expression()


if __name__ == '__main__':
    main()
